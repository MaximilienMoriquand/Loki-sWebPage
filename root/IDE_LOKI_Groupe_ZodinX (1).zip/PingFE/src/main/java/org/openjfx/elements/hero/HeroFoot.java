package org.openjfx.elements.hero;

import org.openjfx.elements.AppElement;

public class HeroFoot extends AppElement
{
    private AppElement nav;
    private AppElement container;
    private AppElement list;
    private AppElement content1;
    private AppElement listelement1;
    private AppElement listelement2;
    private AppElement content2;
    private AppElement listelement3;
    private AppElement content3;

    public HeroFoot(String tagName)
    {
        super(tagName, Hero.singleton.getEngine());
        this.addClass("hero-foot");

        nav = new AppElement("nav", Hero.singleton.getEngine());
        nav.addClass("tabs is-boxed is-fullwidth");
        container = new AppElement("div", Hero.singleton.getEngine());
        container.addClass("container");
        list = new AppElement("ul", Hero.singleton.getEngine());
        listelement1 = new AppElement("li", Hero.singleton.getEngine());
        content1 = new ButtonHero("a","OnclickDocumentation");
        listelement1.appendChild(content1);

        listelement2 = new AppElement("li", Hero.singleton.getEngine());
        content2 = new ButtonHero("a","OnclickGithub");
        listelement2.appendChild(content2);

        listelement3 = new AppElement("li", Hero.singleton.getEngine());
        content3 = new ButtonHero("a","OnclickSite");
        listelement3.appendChild(content3);

        list.appendChild(listelement1);
        list.appendChild(listelement2);
        list.appendChild(listelement3);

        container.appendChild(list);
        nav.appendChild(container);
        this.appendChild(nav);
    }
}
