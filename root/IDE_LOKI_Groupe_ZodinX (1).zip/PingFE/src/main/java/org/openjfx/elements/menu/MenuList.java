package org.openjfx.elements.menu;

import javafx.scene.web.WebEngine;
import org.openjfx.elements.AppElement;
import org.w3c.dom.Element;

import java.util.List;

public class MenuList extends AppElement
{
    private class itemlist extends AppElement
    {
        public itemlist(String tagName, AppElement content, WebEngine engine)
        {
            super(tagName, engine);
            this.appendChild(content);
        }
    }

    public MenuList(String tagName, List<AppElement> elements,  WebEngine engine)
    {
        super(tagName, engine);
        System.out.println(elements);
        this.addClass("menu-list");
        for (var e :elements)
        {
            this.appendChild(new itemlist("li", e, engine));
        }
    }

}