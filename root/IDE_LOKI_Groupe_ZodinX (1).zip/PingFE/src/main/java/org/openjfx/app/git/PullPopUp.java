package org.openjfx.app.git;

import fr.epita.assistants.myide.domain.entity.GitPullEntity;
import fr.epita.assistants.myide.domain.entity.GitPushEntity;
import javafx.concurrent.Worker;
import javafx.scene.web.WebEngine;
import javafx.stage.Stage;
import netscape.javascript.JSObject;
import org.openjfx.App;
import org.openjfx.app.IDE;
import org.openjfx.elements.AppElement;
import org.w3c.dom.Element;

import javax.xml.transform.TransformerException;
import java.io.IOException;

public class PullPopUp extends App {
    private AppElement text;

    private class PopUpElement extends AppElement
    {
        private AppElement article;
        private AppElement message_header;
        private AppElement message_body;
        private AppElement commit;
        private AppElement textarea1;
        private AppElement textarea2;
        private AppElement buttons;
        private AppElement par;
        private final AppElement abortButton;
        private WebEngine engine;

        private PopUpElement(String tagName, WebEngine engine)
        {
            super(tagName, engine);
            this.engine = engine;
            article = new AppElement("div", engine);
            article.addClass("box");

            message_header = new AppElement("div", engine);
            message_header.addClass("box");

            par = new AppElement("p", engine);
            par.setTextContent("Please enter your credential ");

            message_header.appendChild(par);

            message_body = new AppElement("div", engine);
            textarea1 = new AppElement("input", engine);
            textarea1.addClass("input");
            textarea1.setAttribute("placeholder","name");
            textarea1.setAttribute("type", "text");

            textarea2 = new AppElement("input", engine);
            textarea2.addClass("input");
            textarea2.setAttribute("placeholder","password");
            textarea2.setAttribute("type", "text");

            message_body.appendChild(textarea1);
            message_body.appendChild(textarea2);
            buttons = new AppElement("div", engine);
            buttons.addClass("buttons");
            this.commit = new AppElement("button", engine);
            this.commit.addClass("button is-success is-light");
            this.commit.setTextContent("Pull");
            var string ="popupush.commitButton(document.getElementById('" + this.textarea1.getJSVar() + "').value,document.getElementById('" + this.textarea2.getJSVar() + "').value);";
            try {
                App.printDocument(engine.getDocument(),System.out);
            } catch (IOException e) {
                e.printStackTrace();
            } catch (TransformerException e) {
                e.printStackTrace();
            }
            System.out.println(string);
            this.commit.setAttribute(Event.CLICK.toString(), string);

            this.abortButton = new AppElement("button", engine);//this.addItem();
            this.abortButton.addClass("button is-danger is-light");
            this.abortButton.setTextContent("Abort");
            this.abortButton.setAttribute(Event.CLICK.toString(), "popupush.abortButton();");

            buttons.appendChild(commit);
            buttons.appendChild(abortButton);

            article.appendChild(message_header);
            article.appendChild(message_body);
            article.appendChild(buttons);
            this.appendChild(article);
        }
        public AppElement getInput1()
        {
            return this.textarea1;
        }
        public AppElement getInnput2(){return this.textarea2;}
    }
    static boolean answer;
    private PopUpElement popupush = null;

    public PullPopUp()
    {
        super();
    }

    private void dispatch()
    {
        var doc = this.getBrowser().getEngine().getDocument();
        this.updateCSS(IDE.singleton.getTheme().toString());

        Element app = doc.getElementById("app");
        this.popupush = new PullPopUp.PopUpElement("div", this.getBrowser().getEngine());
        app.appendChild(this.popupush.getElement());

        var js = (JSObject) this.getBrowser().getEngine().executeScript("window");
        js.setMember("popupush", this);
    }

    public void abortButton()
    {
        this.close();
    }
    public void commitButton(String message1,String message2)
    {
        try
        {

            IDE.git.auth=message1;
            IDE.git.pwd=message2;
            GitPullEntity gitPushEntity = new GitPullEntity();
            String[] sus = new String[2];
            sus[0]=message1;
            sus[1]=message2;
            var a =gitPushEntity.execute(IDE.git.current_project, sus);
            System.out.println("push ==>"+a.isSuccess());
            this.close();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    public void close()
    {
        this.getStage().close();
    }

    public void show()
    {
        Stage stage = new Stage();
        stage.setTitle("Commit");

        this.load(stage);

        stage.setHeight(180);
        stage.setWidth(720);
        stage.setMaxHeight(180);
        stage.setMaxWidth(720);

        this.getBrowser().getEngine().getLoadWorker().stateProperty().addListener((ov, oldState, newState) ->
        {
            if (newState == Worker.State.SUCCEEDED)
            {
                this.dispatch();
                System.out.println("READY");
            }
        });
    }
}
