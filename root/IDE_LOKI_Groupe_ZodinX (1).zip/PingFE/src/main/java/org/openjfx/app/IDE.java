package org.openjfx.app;

import fr.epita.assistants.MyIde;
import fr.epita.assistants.myide.domain.entity.Mandatory;
import fr.epita.assistants.myide.domain.entity.Node;
import fr.epita.assistants.myide.domain.entity.Project;
import fr.epita.assistants.myide.domain.service.ProjectService;
import javafx.util.Pair;
import org.openjfx.app.explorer.IDEOpenFile;
import org.openjfx.app.explorer.IDESaveAsFile;
import org.openjfx.app.git.Git;
import org.openjfx.elements.explorer.Explorer;
import org.openjfx.app.maven.Maven;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public class IDE
{
    public enum THEME
    {
        DARKCULA(1, "dracula_theme"),
        SOLARISED(2, "solarized_theme"),
        LIGHT(3, "light_theme"),
        SEPIA(4, "sepia_theme"),
        DARK(5, "dark_theme");

        private final int theme;
        private final String name;

        THEME(final int theme, final String name)
        {
            this.theme = theme;
            this.name = name;
        }

        @Override
        public String toString()
        {
            return this.name;
        }
    }

    private THEME theme;

    private Explorer currentExplorer;

    public static IDE singleton = null;
    public Path pathroot = null;
    public final IDE_App app;
    private boolean shown;

    private final ArrayList<String> relative_paths_list;
    private final ArrayList<Pair<Integer, String>> project_file_depth_tree;
    private ProjectService projectService;
    private Project project;
    public static Project projectInit;
    public static Maven maven;
    public static Git git;

    public String current_file_path = "NewfileToBeCreated";
    public String textarea_content = " ";

    public IDE() throws IllegalAccessException
    {
        if (singleton != null)
        {
            throw new IllegalAccessException("IDE singleton exists");
        }

        IDE.singleton = this;
        this.theme = THEME.DARK;
        this.currentExplorer = null;
        this.app = new IDE_App();
        this.shown = false;
        this.relative_paths_list = new ArrayList<>();
        this.project_file_depth_tree = new ArrayList<>();
        this.projectService = MyIde.init(null);
        this.project = null;
    }

    public THEME getTheme()
    {
        return this.theme;
    }

    public void setTheme(THEME theme)
    {
        this.theme = theme;
        this.app.updateCSS(theme.toString());
    }

    public void openSaveAsExplorer()
    {
        if (this.currentExplorer != null)
        {
            return;
        }
        this.currentExplorer = new IDESaveAsFile();
    }

    public void openFileExplorer()
    {
        if (this.currentExplorer != null)
        {
            return;
        }
        this.currentExplorer = new IDEOpenFile();
    }

    public void clearExplorer(Explorer explorer)
    {
        if (this.currentExplorer != explorer || this.currentExplorer == null)
        {
            return;
        }
        this.currentExplorer.close();
        this.currentExplorer = null;
    }

    public void load_project(Path absolute_project_path)
    {
        this.relative_paths_list.clear();
        this.project_file_depth_tree.clear();
        try
        {
            this.project = projectService.load(absolute_project_path);
        }
        catch (Exception e)
        {
            System.out.println(e);
        }
        var a = this.project.getAspects();

        try
        {
            this.maven = new Maven();
            this.maven.current_project = this.project;
            this.git= new Git();
            this.git.current_project=this.project;
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

        construct_relative_paths_list();
        IDE.projectInit = this.project;
        if (!this.shown)
        {
            this.app.show();
            this.shown = true;
        }
    }

    public void construct_relative_paths_list()
    {
        Node root = this.project.getRootNode();
        rec_search(root.getChildren(), 0);
    }

    private void rec_search(List<Node> nodeList, Integer depth)
    {
        StringBuilder spacing = new StringBuilder();
        for (int i = 0;
             i < depth;
             i++)
        {
            spacing.append("  ");
        }
        for (Node node : nodeList)
        {
            if (node.getType().equals(Node.Types.FOLDER))
            {
                this.project_file_depth_tree.add(new Pair<>(depth, spacing + "+ " + node.getPath().getFileName()));
            }
            else
            {
                this.project_file_depth_tree.add(new Pair<>(depth, spacing + "- " + node.getPath().getFileName()));
            }

            this.relative_paths_list.add(node.getPath().toString());
            rec_search(node.getChildren(), depth + 1);
        }
    }

    public void print_project_file_tree()
    {
        System.out.println("PROJECT FILE TREE:");
        System.out.println("Project path : " + this.project.getRootNode().getPath().toAbsolutePath());
        System.out.println("Root directory : " + this.project.getRootNode().getPath().getFileName());
        for (var node : project_file_depth_tree)
        {
            System.out.println(node.getValue());
        }
    }

    public Path project_path()
    {
        return this.project.getRootNode().getPath().toAbsolutePath();
    }

    public Path relative_path_to_absolute(Path relative_path)
    {
        return relative_path.toAbsolutePath();
    }

    public ArrayList<String> get_relative_paths()
    {
        return this.relative_paths_list;
    }

    public ArrayList<Pair<Integer, String>> get_project_tree()
    {
        return this.project_file_depth_tree;
    }
}
