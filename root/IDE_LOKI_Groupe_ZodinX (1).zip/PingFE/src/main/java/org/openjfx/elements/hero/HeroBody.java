package org.openjfx.elements.hero;

import org.openjfx.App;
import org.openjfx.elements.AppElement;

import java.io.File;
import java.util.ArrayList;

public class HeroBody extends AppElement
{
    private AppElement image;
    private AppElement figure;
    private AppElement title;
    private AppElement par;
    private AppElement container;

    public HeroBody(String tagName)
    {
        super(tagName, Hero.singleton.getEngine());
        this.addClass("hero-body");

        container = new AppElement("div", Hero.singleton.getEngine());
        container.addClass("container has-text-centered");

        figure = new AppElement("figure", Hero.singleton.getEngine());
        figure.addClass("image is-128x128 is-inline-block");
        image = new AppElement("img", Hero.singleton.getEngine());
        image.setAttribute("src", App.getFilePath("app/images/lokicenter.svg"));
        figure.appendChild(image);
        title = new AppElement("p", Hero.singleton.getEngine());
        title.addClass("title");
        title.setTextContent("Loki");
        par = new AppElement("p", Hero.singleton.getEngine());
        par.addClass("subtitle");
        par.setTextContent(" A responsive , fast and java-optimised idle");

        container.appendChild(figure);
        container.appendChild(title);
        container.appendChild(par);
        this.appendChild(container);
    }
}
