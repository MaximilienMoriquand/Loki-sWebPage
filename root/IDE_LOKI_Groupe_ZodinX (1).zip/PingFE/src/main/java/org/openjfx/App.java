package org.openjfx;

import javafx.application.Application;
import javafx.concurrent.Worker;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import netscape.javascript.JSObject;
import org.openjfx.app.IDE;
import org.openjfx.controller.WindowController;
import org.openjfx.elements.AppElement;
import org.openjfx.elements.hero.Hero;
import org.openjfx.elements.menu.Menu;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import javax.swing.plaf.synth.SynthTabbedPaneUI;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.*;
import java.util.Map;

/**
 * JavaFX App
 */
public class App extends Application
{
    public static App mainApp = null;

    private double xOffset = 0;
    private double yOffset = 0;
    private WebView browser = null;
    private Scene scene = null;
    private BorderPane root = null;
    private Stage stage = null;

    public WebView getBrowser()
    {
        return this.browser;
    }

    public Stage getStage()
    {
        return this.stage;
    }

    public Scene getScene()
    {
        return this.scene;
    }

    private void HomePage()
    {
        var doc = this.getBrowser().getEngine().getDocument();
        Element app = doc.getElementById("app");
        var hero = new Hero(this);
        app.appendChild(hero.getElement());
    }


    public void updateCSS()
    {
        try
        {
            var doc = this.getBrowser().getEngine().getDocument();
            Element app_style = doc.getElementById("app_style");
            app_style.setAttribute("href", "https://zodinx.github.io/Ping-Themes/dark_theme.css");
        }
        catch (Exception ignored)
        {
        }
    }

    public void updateCSS(final String css)
    {
        try
        {
            /*var doc = this.getBrowser().getEngine().getDocument();
            FileReader file = new FileReader("./css/mystyles.css");
            BufferedReader br = new BufferedReader(file);

            StringBuilder sb = new StringBuilder();
            String line = br.readLine();

            while (line != null)
            {
                sb.append(line);
                sb.append(System.lineSeparator());
                line = br.readLine();
            }

            Element head = doc.getElementById("head");
            Element css_file = doc.createElement("style");
            css_file.setTextContent(sb.toString());
            head.appendChild(css_file);*/

            var doc = this.getBrowser().getEngine().getDocument();
            Element app_style = doc.getElementById("app_style");
            app_style.setAttribute("href", "https://zodinx.github.io/Ping-Themes/" + css + ".css");
        }
        catch (Exception ignored)
        {
        }
    }

    public void reload() throws IOException
    {
        var webEngine = browser.getEngine();

        JSObject window = (JSObject)webEngine.executeScript("window");
        window.setMember("java", this);

        webEngine.executeScript("console.log = function(message) { java.log(message); }");
        webEngine.executeScript("console.error = function(message) { java.log(message); }");

        FileReader file = new FileReader("./app/main.html");
        BufferedReader br = new BufferedReader(file);

        StringBuilder sb = new StringBuilder();
        String line = br.readLine();

        while (line != null)
        {
            sb.append(line);
            sb.append(System.lineSeparator());
            line = br.readLine();
        }
        webEngine.loadContent(sb.toString());
    }

    public void load(Stage stage)
    {
        this.stage = stage;
        this.browser = new WebView();
        this.browser.setMaxHeight(1080);
        this.browser.setMaxWidth(1920);

        try
        {
            this.reload();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

        this.root = new BorderPane(this.browser);
        this.root.getStyleClass().add("browser");
        this.scene = new Scene(this.root, 1920, 1080);

        stage.initStyle(StageStyle.UNDECORATED);
        stage.setScene(this.scene);
        stage.setHeight(800);
        stage.setWidth(1200);
        stage.show();

        WindowController.addResizeListener(stage);
    }

    @Override
    public void start(Stage stage)
    {
        mainApp = this;
        this.load(stage);

        this.getBrowser().getEngine().getLoadWorker().stateProperty().addListener((ov, oldState, newState) ->
        {
            if (newState == Worker.State.SUCCEEDED)
            {
                this.HomePage();
                System.out.println("READY");
            }
        });
    }

    public void log(String text)
    {
        System.out.println(text);
    }

    public static void main(String[] args)
    {
        launch();
    }

    public static String getFilePath(final String relativePath)
    {
        File file = new File(relativePath);
        if (file.exists())
        {
            return "file:///" + file.getAbsolutePath();
        }
        return "";
    }

    // DEBUG ONLY
    public static void printDocument(Document doc, OutputStream out) throws IOException, TransformerException
    {
        TransformerFactory tf = TransformerFactory.newInstance();
        Transformer transformer = tf.newTransformer();
        transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "no");
        transformer.setOutputProperty(OutputKeys.METHOD, "xml");
        transformer.setOutputProperty(OutputKeys.INDENT, "yes");
        transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
        transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");

        transformer.transform(new DOMSource(doc),
                new StreamResult(new OutputStreamWriter(out, "UTF-8")));
    }

}