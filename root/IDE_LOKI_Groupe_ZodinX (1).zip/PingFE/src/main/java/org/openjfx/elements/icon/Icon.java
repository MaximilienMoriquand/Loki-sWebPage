package org.openjfx.elements.icon;

import javafx.scene.web.WebEngine;
import org.openjfx.elements.AppElement;

public class Icon extends AppElement
{
    private AppElement i;

    public Icon(final String icon, WebEngine engine)
    {
        super("span", engine);
        this.addClass("icon");

        this.i = new AppElement("i", engine);
        i.addClass(icon);
        this.appendChild(i);
    }
}
