package org.openjfx.app;

import javafx.concurrent.Worker;
import javafx.scene.web.WebEngine;
import javafx.stage.Stage;
import org.openjfx.App;
import org.openjfx.app.git.Git;
import org.openjfx.elements.AppElement;

import javax.xml.transform.TransformerException;
import java.io.*;
import java.nio.file.Path;
import java.util.Scanner;

public class IDE_App extends App
{
    private MainNavBar navbar;
    public Body body;
    private AppElement div;
    public Path rootproject;
    private Git finalgit;

    public IDE_App()
    {
        super();
    }

    public void show()
    {
        Stage stage = new Stage();
        stage.setTitle("IDE Loki");
        this.load(stage);

        this.getBrowser().getEngine().getLoadWorker().stateProperty().addListener((ov, oldState, newState) ->
        {
            if (newState == Worker.State.SUCCEEDED)
            {
                this.load();
                System.out.println("READY");
                body.engine.executeScript("var content = '" + IDE.singleton.textarea_content + "';var susposter= document.querySelector('.textarea');susposter.value=content;");
                body.engine.executeScript("var impostor= document.querySelector('#pathcontainer');impostor.value='" + IDE.singleton.current_file_path + "';pathsaver();");
            }
        });
    }

    public void close()
    {
        this.getStage().close();
    }

    public void load()
    {
        WebEngine engine = this.getBrowser().getEngine();
        this.updateCSS(IDE.singleton.getTheme().toString());
        try
        {
            String path_root = "";
            File myObj = new File(".loki_data");
            Scanner myReader = new Scanner(myObj);
            while (myReader.hasNextLine())
            {
                path_root += myReader.nextLine();
                System.out.println(path_root);
            }
            myReader.close();


            File root = new File(path_root);
            this.body = new Body(this, root);
            this.navbar = new MainNavBar(engine,true, body);
            // this.hierarchy = new Hierarchy("");
            var doc = engine.getDocument();
            var app = doc.getElementById("app");
            app.appendChild(this.navbar.getElement());

            app.appendChild(this.body.content.getElement());
            try
            {
                printDocument(doc, (OutputStream) System.out);
            }
            catch (IOException e)
            {
                e.printStackTrace();
            }
            catch (TransformerException e)
            {
                e.printStackTrace();
            }
        }

        catch (Exception e)
        {
            // throw new Exception("problem with the file selection");
            System.out.println("problem with the file selection");
            e.printStackTrace();
            System.exit(666);
        }
    }

    @Override
    public void updateCSS()
    {
        this.updateCSS(IDE.singleton.getTheme().toString());
    }
}
