package org.openjfx.app.explorer;

import fr.epita.assistants.myide.domain.entity.Node;
import org.openjfx.app.IDE;
import org.openjfx.elements.AppElement;
import org.openjfx.elements.explorer.Explorer;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Path;

public class IDESaveAsFile extends Explorer
{
    public IDESaveAsFile()
    {
        super(false);
        this.setPath(IDE.singleton.project_path());
        this.createFile(Node.Types.FILE);
        this.show();
    }

    @Override
    public void save(Path path, String name)
    {
        var filePath = path.toString();
        if (filePath.contains("/")){
            filePath += "/" + name;
        }
        else {
            filePath += "\\" + name;
        }

        var string = IDE.singleton.app.getBrowser().getEngine().getDocument().getElementById("saveinput").getTextContent();
        System.out.println(string);
        String[] splits = string.split("\n");

        try {
            File newFile = new File(path.toString());
            System.out.println("Creating file at: " + filePath);
            if (newFile.createNewFile()) {
                System.out.println("File created: " + newFile.getName());
            } else {
                System.out.println("File already exists.");
            }
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }

        try {
            FileWriter myWriter = new FileWriter(filePath);
            for (var line : splits) {
                myWriter.write(line + "\n");
            }
            myWriter.close();
            System.out.println("Successfully wrote to the file.");
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }

        string = string.replace("\r", "");
        string = string.replace("\n", "\\n");
        filePath = filePath.replace("\\", "\\\\");

        IDE.singleton.current_file_path = filePath;
        IDE.singleton.textarea_content = string;

        IDE.singleton.app.body.reloadHierarchy();
        try {
            IDE.singleton.app.reload();
        }
        catch (Exception e){
            System.out.println("Reload failed");
        }

        IDE.singleton.clearExplorer(this);
    }

    @Override
    public void hide()
    {
        IDE.singleton.clearExplorer(this);
    }
}
