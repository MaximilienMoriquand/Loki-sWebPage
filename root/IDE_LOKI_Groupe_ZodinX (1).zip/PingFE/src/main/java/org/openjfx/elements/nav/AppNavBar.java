package org.openjfx.elements.nav;

import javafx.scene.web.WebEngine;
import org.openjfx.App;
import org.openjfx.elements.*;

import java.util.ArrayList;
import java.util.List;

public class AppNavBar extends AppElement
{
    public class Dropdown extends AppElement
    {
        private final AppElement navLink;
        private final AppElement dropdown;
        private final WebEngine engine;

        public Dropdown(WebEngine engine)
        {
            super("div", engine);

            this.engine = engine;
            this.addClass("navbar-item has-dropdown is-hoverable");

            this.navLink = new AppElement("a", engine);
            this.navLink.addClass("navbar-link");
            this.appendChild(this.navLink);

            this.dropdown = new AppElement("div", engine);
            this.dropdown.addClass("navbar-dropdown");
            this.appendChild(this.dropdown);
        }

        public final AppElement getNavLink()
        {
            return this.navLink;
        }

        public final AppElement getDropdown()
        {
            return this.dropdown;
        }

        public final AppElement addItem()
        {
            var ret = AppNavBar.createItem(this.engine);
            this.dropdown.appendChild(ret);
            return ret;
        }
    }

    public class Menu extends AppElement
    {
        private final AppElement navBarStart;
        private final AppElement navBarEnd;

        public Menu(WebEngine engine)
        {
            super("div", engine);
            this.addClass("navbar-menu");

            this.navBarStart = new AppElement("div", engine);
            this.navBarStart.addClass("navbar-start");
            this.appendChild(this.navBarStart);

            this.navBarEnd = new AppElement("div", engine);
            this.navBarEnd.addClass("navbar-end");
            this.appendChild(this.navBarEnd);
        }

        public final AppElement getNavBarStart()
        {
            return this.navBarStart;
        }

        public final AppElement getNavBarEnd()
        {
            return this.navBarEnd;
        }
    }

    public class Brand extends AppElement
    {
        public class Burger extends AppElement
        {
            private List<AppElement> spans;

            public Burger(Menu menu, WebEngine engine)
            {
                super("a", engine);
                this.addClass("navbar-burger");
                this.setAttribute("role", "button");
                this.setAttribute("aria-label", "menu");
                this.setAttribute("aria-expanded", "false");
                this.setAttribute("data-target", menu.getJSVar());

                spans = new ArrayList<>();
                for (int i = 0; i < 3; i++)
                {
                    var span = new AppElement("span", engine);
                    span.setAttribute("aria-hidden", "true");

                    spans.add(span);
                    this.appendChild(span);
                }
            }
        }

        private final AppElement item;
        private final Burger burger;

        public Brand(Menu menu, WebEngine engine)
        {
            super("div", engine);
            this.addClass("navbar-brand");

            this.item = AppNavBar.createItem(engine);
            this.appendChild(this.item);

            this.burger = new Burger(menu, engine);
            this.appendChild(this.burger);
        }

        public final AppElement getItem()
        {
            return this.item;
        }
    }

    private final Brand navBrand;
    private final Menu navMenu;
    private List<AppElement> dropdowns;

    public AppNavBar(WebEngine engine)
    {
        super("nav", engine);
        this.addClass("navbar is-fixed-top");
        this.setAttribute("role", "navigation");
        this.setAttribute("aria-label", "main navigation");

        this.navMenu = new Menu(engine);
        this.navBrand = new Brand(this.navMenu, engine);

        this.appendChild(this.navBrand);
        this.appendChild(this.navMenu);
        this.dropdowns = new ArrayList<>();
    }

    public final Brand getNavBrand()
    {
        return this.navBrand;
    }

    public final Menu getNavMenu()
    {
        return this.navMenu;
    }

    public static final AppElement createItem(WebEngine engine)
    {
        var ret = new AppElement("a", engine);
        ret.addClass("navbar-item");
        return ret;
    }

    public final Dropdown createDropdown(WebEngine engine)
    {
        var dropdown = new Dropdown(engine);
        this.dropdowns.add(dropdown);
        return dropdown;
    }
}
