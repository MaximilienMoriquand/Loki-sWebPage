package org.openjfx.elements.hero;

import fr.epita.assistants.myide.domain.entity.Node;
import javafx.scene.web.WebEngine;
import org.openjfx.App;
import org.openjfx.app.IDE;
import org.openjfx.elements.explorer.Explorer;
import org.openjfx.app.webview.WebWindow;
import org.openjfx.elements.AppElement;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;


public class Hero extends AppElement {
    public class HeroOpenProjectExplorer extends Explorer {
        public HeroOpenProjectExplorer() {
            super(false);
        }

        @Override
        public void save(Path path, String name) {
            String separator = "\\";
            String string = new String(path.toString() + "\\" + name);
            if (System.getProperty("os.name") != "Windows 10")
            {
                string.replace("\\", "/");
                separator="/";
            }

            File f = new File(string);

            try {
                if (f.mkdir()) {
                    System.out.println("Directory Created");
                    string+=separator;
                    File pom = new File(string+"pom.xml");
                    pom.createNewFile();
                    FileWriter fileWriter=new FileWriter(pom);
                    String content = new String("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
                            "<project xmlns=\"http://maven.apache.org/POM/4.0.0\"\n" +
                            "         xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"\n" +
                            "         xsi:schemaLocation=\"http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd\">\n" +
                            "    <modelVersion>4.0.0</modelVersion>\n" +
                            "\n" +
                            "    <groupId>org.example</groupId>\n" +
                            "    <artifactId>"+name+"</artifactId>\n" +
                            "    <version>1.0-SNAPSHOT</version>\n" +
                            "\n" +
                            "    <properties>\n" +
                            "        <maven.compiler.source>16</maven.compiler.source>\n" +
                            "        <maven.compiler.target>16</maven.compiler.target>\n" +
                            "    </properties>\n" +
                            "\n" +
                            "</project>");
                    fileWriter.write(content);
                    fileWriter.close();
                    this.open(f.toPath());
                } else {
                    System.out.println("Directory is not created");
                }
            } catch (Exception e) {


                this.close();
            }
        }

        @Override
        public void open(Path path) {
            this.close();
            Hero.singleton.unload();
            IDE.singleton.load_project(path);
            FileWriter myWriter = null;
            try {
                myWriter = new FileWriter(".loki_data");
                myWriter.write(path.toString());
                myWriter.close();
            } catch (IOException e) {
                e.printStackTrace();
            }

        }

        @Override
        public void hide() {
            this.close();
            Hero.singleton.currentExplorer = null;
        }
    }

    public static WebEngine engine;
    public static Hero singleton = null;
    private Explorer currentExplorer;

    private App app;
    private HeaderHero header;
    private HeroBody body;
    private HeroFoot heroFoot;
    private WebWindow webWindow;

    public Hero(App app) {
        super("section", app.getBrowser().getEngine());

        try {
            new IDE();
        } catch (Exception ignored) {

        }

        singleton = this;
        engine = app.getBrowser().getEngine();
        app.updateCSS();
        this.app = app;
        this.currentExplorer = null;
        header = new HeaderHero("div");
        body = new HeroBody("div");
        heroFoot = new HeroFoot("div");
        this.addClass("hero is-success is-fullheight");
        this.appendChild(header);
        this.appendChild(body);
        this.appendChild(heroFoot);
    }

    public void openProjectExplorer() {
        if (this.currentExplorer != null) {
            System.out.println("Explorer already opened!");
            return;
        }
        this.currentExplorer = new HeroOpenProjectExplorer();
        this.currentExplorer.setPath(Paths.get(System.getProperty("user.home")/*"D:/Users/Benoist/Documents"*/));
        this.currentExplorer.show();
    }

    public void openNewProjectExplorer() {
        if (this.currentExplorer != null) {
            System.out.println("Explorer already opened!");
            return;
        }
        this.currentExplorer = new HeroOpenProjectExplorer();
        this.currentExplorer.setPath(Paths.get(System.getProperty("user.home")));
        this.currentExplorer.createFile(Node.Types.FOLDER);
        this.currentExplorer.show();
    }

    public void OpenDoc() {
        WebWindow.show("https://maximilienmoriquand.github.io/Loki-sWebPage/root/Basic.html");
    }

    public void OpenBenoist() // OwO
    {
        WebWindow.show("https://github.com/ZOdinX");
    }

    public void OpenSite() {
        WebWindow.show("https://maximilienmoriquand.github.io/Loki-sWebPage/root/index.html");
    }

    public WebEngine getEngine() {
        return this.engine;
    }

    public void unload() {
        if (this.currentExplorer != null) {
            this.currentExplorer.close();
            this.currentExplorer = null;
        }

        this.app.getStage().close();
        // Time to get garbage collected
        Hero.singleton = null;
    }
}
