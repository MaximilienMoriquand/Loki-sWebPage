package org.openjfx.app.hierarchy;

import javafx.scene.web.WebEngine;
import netscape.javascript.JSObject;
import org.openjfx.App;
import org.openjfx.app.IDE;
import org.openjfx.elements.AppElement;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.EventListener;
import java.util.List;

public class Hierarchy {
    ArrayList<FolderElement> folders = new ArrayList<>();
    ArrayList<FileElement> files = new ArrayList<>();
    List<String> paths;
    public AppElement Menue;
    File root;
    App window;
    public WebEngine engine;

    private class ListChild extends AppElement {

        public ListChild(String tagName, WebEngine engine) {
            super("ul", engine);
            this.addClass("menu-list");
            this.addEventListener(Event.CLICK, "OnclickButton");
            // this.setAttribute("hidden","false");
        }

        public void OnclickButton() {
            System.out.println("hiding");
            if (this.getAttribute("hidden").equals("true"))
                this.setAttribute("hidden", "false");
            else
                this.setAttribute("hidden", "true");
        }
    }

    private class FolderElement extends AppElement {
        public String name;

        public FolderElement(String tagName, WebEngine engine, String name) {
            super(tagName, engine);
            this.name = name;
            AppElement nameElelemnt = new AppElement("p", engine);

            nameElelemnt.addClass("menu-label");
            nameElelemnt.setTextContent(name);
            this.setAttribute(AppElement.Event.CLICK.toString(), "OnclickButton()");

            this.appendChild(nameElelemnt);


        }

        public void OnclickButton() {
            System.out.println("hiding");
        }

    }

    private AppElement truc;

    public class FileElement extends AppElement
    {
        public String name;
        public WebEngine engine;
        private EventListener clicker;

        public FileElement(String tagName, WebEngine engine, String name, File file)
        {
            super("li", engine);
            this.engine = engine;
            this.name = name;
            AppElement contentname = new AppElement("a", engine);
            contentname.setTextContent(name);
            this.appendChild(contentname);

            String file_text = "Possible error while reading file";
            try {
                file_text = Files.readString(Path.of(file.getAbsolutePath()));
            }
            catch (Exception e)
            {
                return;
            }

            file_text = file_text.replace("\r", "");
            file_text = file_text.replace("\n", "\\n");
            System.out.println(file_text);

            String path = Path.of(file.getAbsolutePath()).toString();
            path = path.replace("\\", "\\\\");

            String chose = "var content = '" + file_text + "';var susposter= document.querySelector('.textarea');susposter.value=content;var impostor= document.querySelector('#pathcontainer');impostor.value='" + path + "';console.log('IMPOSTOR PATH CONTAINER = ' + impostor.value);pathsaver();";

            this.setAttribute("ONCLICK", chose);
        }

        public void FileClicker()
        {
            System.out.println("CLICKS");
        }


    }



    public AppElement content;//= new AppElement("div",engine);

    public Hierarchy(File root, App window) {

        this.window = window;
        this.engine = window.getBrowser().getEngine();
        content = new AppElement("div", engine);
        this.root = root;
        AppElement aside = new AppElement("aside", engine);
        aside.addClass("menu");
        aside.setAttribute("style", "height:100px;width:100px"); // MODIFICATION 01
        ListChild rootelement = new ListChild("ul", engine);
        rootelement.addClass("menu-list");
        AppElement list = new AppElement("ul", engine);
        list.addClass("menu-list");
        if (root.isDirectory() && root.listFiles().length != 0) {
            rec_build(root, rootelement);
        }
        aside.appendChild(rootelement);
        content.appendChild(aside);
        this.Menue = aside;

    }

    private void rec_build(File folder, AppElement Parent)
    {
        var List = new ListChild("ul", engine);
        var a = folder.listFiles();
        for (var file : a) {
            System.out.println("checking the file :" + file.getName());
            if (file.isDirectory()) {

                FolderElement folderElement1 = new FolderElement("li", engine, file.getName());
                this.folders.add(folderElement1);
                rec_build(file, folderElement1);
                List.appendChild(folderElement1);

            } else {
                FileElement fileElement = new FileElement("li", engine, file.getName(), file);
                this.files.add(fileElement);

                List.appendChild(fileElement);
            }
        }
        Parent.appendChild(List);
    }

    public void FileClicker()
    {
        System.out.println("CLICKS");
    }

    public void load(File root) {

        var Hierachy = new Hierarchy(root, window);
        this.Menue = Hierachy.Menue;
        this.content = Hierachy.content;
        this.window.updateCSS();
        // Set the title
        var span = new AppElement("span", engine);
        span.setTextContent("IDE");
        var doc = engine.getDocument();
        var app = doc.getElementById("app");
        JSObject window = (JSObject) engine.executeScript("window");
        window.setMember("explorer", this);
        app.appendChild(this.content.getElement());
    }

}


