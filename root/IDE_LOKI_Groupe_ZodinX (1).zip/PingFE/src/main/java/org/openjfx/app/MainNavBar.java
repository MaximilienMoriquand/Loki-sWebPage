package org.openjfx.app;

import javafx.scene.web.WebEngine;
import netscape.javascript.JSObject;
import org.openjfx.App;
import org.openjfx.app.hierarchy.Hierarchy;
import org.openjfx.app.maven.Maven;
import org.openjfx.elements.AppElement;
import org.openjfx.elements.nav.AppNavBar;

import javax.xml.transform.TransformerException;
import java.awt.*;
import java.io.Console;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;


public class MainNavBar extends AppNavBar {
    public WebEngine engineE;

    public class ThemeDropDown extends Dropdown {
        private final AppElement draculaButton;
        private final AppElement solarisedButton;
        private final AppElement lightButton;
        private final AppElement sepiaButton;
        private final AppElement darkButton;

        public ThemeDropDown(MainNavBar bar, WebEngine engine) {
            super(engine);
            engineE = engine;
            this.getNavLink().setTextContent("Themes");

            this.draculaButton = this.addItem();
            this.draculaButton.setTextContent("Dracula");
            this.draculaButton.addEventListener(Event.CLICK, bar, "changeDracula");

            this.solarisedButton = this.addItem();
            this.solarisedButton.setTextContent("Solarised");
            this.solarisedButton.addEventListener(Event.CLICK, bar, "changeSolarised");

            this.lightButton = this.addItem();
            this.lightButton.setTextContent("Light");
            this.lightButton.addEventListener(Event.CLICK, bar, "changeLight");

            this.sepiaButton = this.addItem();
            this.sepiaButton.setTextContent("Sepia");
            this.sepiaButton.addEventListener(Event.CLICK, bar, "changeSepia");

            this.darkButton = this.addItem();
            this.darkButton.setTextContent("Dark");
            this.darkButton.addEventListener(Event.CLICK, bar, "changeDark");

            /*try {
                engine.executeScript(bar.getJSVar() + ".changeDracula();");
            } catch (Exception ignored) {
                System.err.println(ignored.toString());
            }*/

            bar.getNavMenu().getNavBarStart().appendChild(this);
        }
    }

    public class FileDropDown extends Dropdown {
        private final AppElement openButton;
        private final AppElement saveButton;
        private final AppElement saveAsButton;
        private final AppElement newFileButton;

        public FileDropDown(MainNavBar bar, WebEngine engine) {
            super(engine);
            this.getNavLink().setTextContent("File");


            this.newFileButton = this.addItem();
            this.newFileButton.setTextContent("New");
            this.newFileButton.addEventListener(Event.CLICK, bar, "onclickNew");

            this.openButton = this.addItem();
            this.openButton.setTextContent("Open");
            openButton.addEventListener(Event.CLICK, bar, "onclickOpen");

            /*item = this.addItem();
            item.setTextContent("Save");*/

            this.saveButton = this.addItem();
            this.saveButton.setTextContent("Save");
            String chose = "amogus();";
            this.saveButton.setAttribute("onmouseover", chose);
            this.saveButton.addEventListener(Event.CLICK, bar, "OnClickSaveFile");

            this.saveAsButton = this.addItem();
            this.saveAsButton.setTextContent("Save As");
            this.saveAsButton.setAttribute("onmouseover", chose);
            this.saveAsButton.addEventListener(Event.CLICK, bar, "saveAsFile");

            /*item = this.addItem();
            item.setTextContent("Close");*/

            bar.getNavMenu().getNavBarStart().appendChild(this);
        }

        public final AppElement getOpenButton() {
            return this.openButton;
        }
    }

    public class DDConsole extends Dropdown {
        private final AppElement Linux;
        private final AppElement Windows;

        public DDConsole(MainNavBar bar, WebEngine engine) {
            super(engine);
            this.getNavLink().setTextContent("Console");

            this.Linux = this.addItem();
            this.Linux.setTextContent("Unix (Gnome)");
            this.Linux.addEventListener(Event.CLICK, bar, "onclickConsoleLinux");

            this.Windows = this.addItem();
            this.Windows.setTextContent("Window");
            this.Windows.addEventListener(Event.CLICK, bar, "onclickConsoleWindow");
            bar.getNavMenu().getNavBarStart().appendChild(this);
        }


    }

    public class Gitdd extends Dropdown {
        private final AppElement pushButton;
        private final AppElement addButton;
        private final AppElement pullButton;
        private final AppElement commitButton;

        public Gitdd(MainNavBar bar, WebEngine engine) {
            super(engine);
            this.getNavLink().setTextContent("Git");

            this.addButton = this.addItem();
            this.addButton.setTextContent("Add current file");
            this.addButton.addEventListener(Event.CLICK, bar, "OnclickGitadd");

            this.commitButton = this.addItem();
            this.commitButton.setTextContent("Commit");
            this.commitButton.addEventListener(Event.CLICK, bar, "OnclickGitcommit");

            this.pushButton = this.addItem();
            this.pushButton.setTextContent("Push");
            this.pushButton.addEventListener(Event.CLICK, bar, "OnclickGitpush");
            this.pullButton = this.addItem();
            this.pullButton.addEventListener(Event.CLICK, bar, "OnclickGitpull");
            this.pullButton.setTextContent("Pull");

            bar.getNavMenu().getNavBarStart().appendChild(this);
        }


    }

    private FileDropDown file_dd = null;
    private ThemeDropDown theme_dd = null;
    private Gitdd gitdd = null;
    private Body body;
    public AppElement pathContainer;
    public DDConsole ConsoleButton;

    public MainNavBar(WebEngine engine, boolean nude, Body body) {

        super(engine);
        //this.addClass("is-dark");

        this.body = body;
        // Set our brand icon
        AppElement img = new AppElement("img", engine);
        img.setAttribute("src", App.getFilePath("app/images/loki.svg"));
        img.setAttribute("width", "64");
        img.setAttribute("height", "64");

        AppElement text = new AppElement("span", engine);
        text.setTextContent("LOKI");

        var brand = this.getNavBrand();

        var secret = new AppElement("div", engine);
        secret.setAttribute("id", "saveinput");
        secret.setAttribute("hidden", "true");

        this.pathContainer = new AppElement("div", engine);
        this.pathContainer.setAttribute("id", "pathcontainer");
        this.pathContainer.setAttribute("hidden", "true");

        brand.getItem().appendChild(secret);
        brand.getItem().appendChild(pathContainer);
        brand.getItem().appendChild(img);
        brand.getItem().appendChild(text);


        if (nude) {
            var menu = this.getNavMenu();
            var menu_start = menu.getNavBarStart();

            this.file_dd = new FileDropDown(this, engine);

            this.gitdd = new Gitdd(this, engine);
            this.ConsoleButton = new DDConsole(this, engine);
            var edit_dd = this.createDropdown(engine);
            edit_dd.getNavLink().setTextContent("Edit");
            // File File Dropdown
            var item = edit_dd.addItem();
            item.setTextContent("Select All");


            item = edit_dd.addItem();
            item.setTextContent("Undo");

            item = edit_dd.addItem();
            item.setTextContent("Redo");

            item = edit_dd.addItem();
            item.setTextContent("Copy");

            item = edit_dd.addItem();
            item.setTextContent("Cut");

            item = edit_dd.addItem();
            item.setTextContent("Paste");
            // End File Dropdown

            var set_dd = this.createDropdown(engine);
            set_dd.getNavLink().setTextContent("Settings");


            var navbar_dropdown = new AppElement("div", engine);
            navbar_dropdown.addClass("navbar-dropdown");

            var nested_dropdow = new AppElement("div", engine);
            nested_dropdow.addClass("nested dropdown");

            var navbar_item = new AppElement("a", engine);
            navbar_item.addClass("navbar-item");

            var span_icontext = new AppElement("span", engine);
            span_icontext.addClass("icon-text");

            var Theme = new AppElement("a", engine);
            Theme.setTextContent("Theme");

            var User = new AppElement("a", engine);
            User.setTextContent("User");

            var Git = new AppElement("a", engine);
            Git.setTextContent("Git");

            var Syntaxe = new AppElement("a", engine);
            Syntaxe.setTextContent("Syntaxe");


            item = set_dd.addItem();
            item.setTextContent("User");

            item = set_dd.addItem();
            item.setTextContent("Git");

            item = set_dd.addItem();
            item.setTextContent("Maven");

            item = set_dd.addItem();
            item.setTextContent("Syntax");


            var build_dd = this.createDropdown(engine);
            build_dd.getNavLink().setTextContent("Build");
            // File File Dropdown
            item = build_dd.addItem();
            item.setTextContent("Build Project");
            item.addEventListener(Event.CLICK, this, "OnclickMavenBuildProject");
/*
            item = build_dd.addItem();
            item.setTextContent("Build Module");
            item.addEventListener(Event.CLICK, this, "OnclickMavenBuildModule");
*/
            item = build_dd.addItem();
            item.setTextContent("Package");
            item.addEventListener(Event.CLICK, this, "OnclickMavenPackage");
            // End File Dropdown

            var run_dd = this.createDropdown(engine);
            run_dd.getNavLink().setTextContent("Run");

            // File File Dropdown
            item = run_dd.addItem();
            item.setTextContent("Debug");
            item.addEventListener(Event.CLICK, this, "OnclickMavenRunDebug");

            item = run_dd.addItem();
            item.setTextContent("Release");
            item.addEventListener(Event.CLICK, this, "OnclickMavenRunRelease");
            // End File Dropdown

            if (nude) {
          //      menu_start.appendChild(edit_dd);
          //      menu_start.appendChild(set_dd);
                menu_start.appendChild(build_dd);
           //     menu_start.appendChild(run_dd);
                menu_start.appendChild(gitdd);
                menu_start.appendChild(ConsoleButton);

            }

            var close_item = AppNavBar.createItem(engine);
            menu.getNavBarEnd().appendChild(close_item);
            close_item.addClass("is-danger");

            var icon = new AppElement("span", engine);
            icon.addClass("icon");
            var symbol = new AppElement("i", engine);
            symbol.addClass("fas fa-times");
            icon.appendChild(symbol);
            close_item.appendChild(icon);
            close_item.addEventListener(Event.CLICK, this, "closeIDE");
            this.theme_dd = new ThemeDropDown(this, engine);
            menu_start.appendChild(this.ConsoleButton);
        }
    }

    public void onclickNew() throws IOException {
        IDE.singleton.current_file_path = "NewfileToBeCreated";
        IDE.singleton.textarea_content = " ";

        IDE.singleton.app.body.reloadHierarchy();
        IDE.singleton.app.reload();
    }

    public void onclickOpen() {
        try {
            IDE.singleton.openFileExplorer();
        } catch (Exception exception) {
            System.out.println(exception.toString());
        }

    }

    public void saveAsFile()
    {
        IDE.singleton.openSaveAsExplorer();
    }

    public void OnclickMavenBuildProject()
    {
        System.out.println("Building Project...");
        var projectInit = IDE.projectInit;
        try {
            IDE.maven.compile();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void OnClickSaveFile() throws IOException {
        var string = engineE.getDocument().getElementById("saveinput").getTextContent();
        System.out.println(string);

        var path = engineE.getDocument().getElementById("pathcontainer").getTextContent();
        System.out.println("PATH IS : " + path);

        if (path.equals("NewfileToBeCreated")){
            saveAsFile();
            return;
        }

        String[] splits = string.split("\n");


        try {
            FileWriter myWriter = new FileWriter(path);
            int i = 1;
            for (var line : splits) {
                if (i != 0) {
                    myWriter.write(line + "\n");
                }
                i++;
            }
            myWriter.close();
            System.out.println("Successfully wrote to the file.");
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }

        string = string.replace("\r", "");
        string = string.replace("\n", "\\n");
        path = path.replace("\\", "\\\\");

        IDE.singleton.current_file_path = path;
        IDE.singleton.textarea_content = string;

        IDE.singleton.app.body.reloadHierarchy();
        IDE.singleton.app.reload();
    }

    public void onclickConsoleWindow() {
        System.out.println("amogus");
        try {
            Console console = System.console();
            if (console == null && !GraphicsEnvironment.isHeadless()) {
                String filename = App.class.getProtectionDomain().getCodeSource().getLocation().toString().substring(6);

                Runtime.getRuntime().exec(new String[]{"cmd", "/c", "start", "cmd",});
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public void onclickConsoleLinux() {
        System.out.println("amogux");
        try {
            Console console = System.console();
            if (console == null && !GraphicsEnvironment.isHeadless()) {
                String filename = App.class.getProtectionDomain().getCodeSource().getLocation().toString().substring(6);

                Runtime.getRuntime().exec(new String[]{"gnome-terminal"});
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void OnclickMavenPackage() {
        /*
        try {
            App.printDocument(engineE.getDocument(),System.out);
            var string = engineE.getDocument().getElementById("saveinput");
            System.out.println("=====================\n"+string.getTextContent());
        } catch (IOException e) {
            e.printStackTrace();
        } catch (TransformerException e) {
            e.printStackTrace();
        }*/
        System.out.println("Packaging...");
        IDE.maven.packages();
        System.out.println("Packaged");
    }

    public void OnclickMavenBuildModule() {
        System.out.println("Maven compiling...");
        var projectInit = IDE.projectInit;
        try {
            IDE.maven.compile();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void OnclickMavenRunRelease() {
        System.out.println("Maven run...");
        var projectInit = IDE.projectInit;
        try {
            IDE.maven.exec();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void OnclickMavenRunDebug() {
        System.out.println("Maven debug...");
        var projectInit = IDE.projectInit;
        try {
            IDE.maven.exec();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void OnclickGitadd() {
        System.out.println("add click");

        var root_path = IDE.singleton.project_path().toString();
        System.out.println(root_path);
        IDE.git.add(engineE, root_path, "");
    }

    public void OnclickGitcommit() {
        System.out.println("commit click ");
        try {
            IDE.git.commit();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void OnclickGitpull() {
        System.out.println("amogus pull ");
        try {
            IDE.git.pull();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void OnclickGitpush() {
        System.out.println("amogus push");
        try {
            IDE.git.push();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public FileDropDown getFileDropdown() {
        return this.file_dd;
    }

    public void changeDracula() {
        IDE.singleton.setTheme(IDE.THEME.DARKCULA);
    }

    public void changeSolarised() {
        IDE.singleton.setTheme(IDE.THEME.SOLARISED);
    }

    public void changeLight() {
        IDE.singleton.setTheme(IDE.THEME.LIGHT);
    }

    public void changeSepia() {
        IDE.singleton.setTheme(IDE.THEME.SEPIA);
    }

    public void changeDark() {
        IDE.singleton.setTheme(IDE.THEME.DARK);
    }

    public void closeIDE() {
        System.exit(0);
    }
}
