package org.openjfx.app.maven;

import fr.epita.assistants.myide.domain.service.MavenService;
import javafx.scene.web.WebEngine;
import org.openjfx.app.IDE;
import org.openjfx.elements.AppElement;
import fr.epita.assistants.myide.domain.entity.*;

import java.util.Locale;

public class Maven
{
    public enum TASK
    {
        COMPILE,
        CLEAN,
        EXEC,
        INSTALL,
        TEST,
        TREE,
        PACKAGE

    }

    public class MavenButton extends AppElement
    {
        public MavenButton(String tagName, WebEngine engine, TASK task)
        {
            super(tagName, engine);
            this.addClass("button");
            this.setTextContent(task.name().toLowerCase(Locale.ROOT));
        }
    }

    public Project current_project;
    public static Maven singleton;

    public Maven() throws Exception
    {
        if (singleton != null)
        {
            throw new Exception("maven object already created");
        }
        this.current_project = IDE.projectInit;
    }

    public void exec_cmd(TASK task, Object... args)
    {
        switch (task)
        {
            case EXEC:
                exec(args);
            case TEST:
                test(args);
            case TREE:
                tree(args);
            case CLEAN:
                clean(args);
            case COMPILE:
                compile(args);
            case INSTALL:
                install(args);
            case PACKAGE:
                packages(args);
        }
    }

    public void compile(Object... args)
    {
        MavenCompileEntity compileEntity = new MavenCompileEntity();
        var a = compileEntity.execute(this.current_project, args);
        System.out.println("maven compile return : " + a.isSuccess());
    }

    public void clean(Object... args)
    {
        MavenCleanEntity cleanEntity = new MavenCleanEntity();
        var a = cleanEntity.execute(this.current_project, args);
        System.out.println("maven clean return : " + a.isSuccess());
    }

    public void exec(Object... args)
    {
        MavenExecEntity execEntity = new MavenExecEntity();
        var a = execEntity.execute(this.current_project, args);
        System.out.println("maven exec return : " + a.isSuccess());
    }

    public void install(Object... args)
    {
        MavenInstallEntity installEntity = new MavenInstallEntity();
        var a = installEntity.execute(this.current_project, args);
        System.out.println("maven install return : " + a.isSuccess());
    }

    public void packages(Object... args)
    {
        MavenPackageEntity packageEntity = new MavenPackageEntity();
        var a = packageEntity.execute(this.current_project, args);
        System.out.println("maven Package return : " + a.isSuccess());
    }

    public void test(Object... args)
    {
        MavenTestEntity mavenTestEntity = new MavenTestEntity();
        var a = mavenTestEntity.execute(this.current_project, args);
        System.out.println("maven test return : " + a.isSuccess());
    }

    public void tree(Object... args)
    {
        MavenTreeEntity mavenTreeEntity = new MavenTreeEntity();
        var a = mavenTreeEntity.execute(this.current_project, args);
        System.out.println("maven tree return : " + a.isSuccess());
    }
}
