package org.openjfx.elements.menu;

import javafx.scene.web.WebEngine;
import org.openjfx.elements.AppElement;

import java.util.List;

public class Menu extends AppElement
{
    public Menu(String tagName, List<AppElement> elements, WebEngine engine)
    {
        super(tagName, engine);
        MenuList list = new MenuList("ul", elements, engine);
        addClass("menu");
        this.appendChild(list);
    }
}