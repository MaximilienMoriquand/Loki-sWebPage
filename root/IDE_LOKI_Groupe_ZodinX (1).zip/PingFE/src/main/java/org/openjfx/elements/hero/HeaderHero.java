package org.openjfx.elements.hero;

import org.openjfx.elements.AppElement;

import java.util.ArrayList;

public class HeaderHero extends AppElement
{
    private HNave hNave;

    public HeaderHero(String tagName)
    {
        super(tagName, Hero.singleton.getEngine());
        this.addClass("hero-head");
         hNave = new HNave("header");
        this.appendChild(hNave);
    }
}
