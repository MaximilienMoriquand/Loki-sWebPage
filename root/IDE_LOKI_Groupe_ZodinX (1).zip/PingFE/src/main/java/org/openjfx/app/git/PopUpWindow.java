package org.openjfx.app.git;

import fr.epita.assistants.myide.domain.entity.GitCommitEntity;
import javafx.application.Platform;
import javafx.concurrent.Worker;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import javafx.stage.*;
import netscape.javascript.JSObject;
import org.openjfx.App;
import org.openjfx.app.IDE;
import org.openjfx.controller.WindowController;
import org.openjfx.elements.AppElement;
import org.w3c.dom.Element;

import javax.xml.transform.TransformerException;
import java.io.*;


public class PopUpWindow extends App
{
    private AppElement text;

    private class PopUpElement extends AppElement
    {
        private AppElement article;
        private AppElement message_header;
        private AppElement message_body;
        private AppElement commit;
        private AppElement textarea;
        private AppElement buttons;
        private AppElement par;
        private final AppElement abortButton;
        private WebEngine engine;

        public PopUpElement(String tagName, WebEngine engine)
        {
            super(tagName, engine);
            this.engine = engine;
            article = new AppElement("div", engine);
            article.addClass("box");

            message_header = new AppElement("div", engine);
            message_header.addClass("box");

            par = new AppElement("p", engine);
            par.setTextContent("Please enter your commit message");

            message_header.appendChild(par);

            message_body = new AppElement("div", engine);
            textarea = new AppElement("input", engine);
            textarea.addClass("input");
            textarea.setAttribute("type", "text");
            text = textarea;
            message_body.appendChild(text);

            buttons = new AppElement("div", engine);
            buttons.addClass("buttons");
            this.commit = new AppElement("button", engine);
            this.commit.addClass("button is-success is-light");
            this.commit.setTextContent("Commit");
            this.commit.setAttribute(Event.CLICK.toString(), "popup.commitButton(document.getElementById('" + this.textarea.getJSVar() + "').value);");

            this.abortButton = new AppElement("button", engine);//this.addItem();
            this.abortButton.addClass("button is-danger is-light");
            this.abortButton.setTextContent("Abort");
            this.abortButton.setAttribute(Event.CLICK.toString(), "popup.abortButton();");

            buttons.appendChild(commit);
            buttons.appendChild(abortButton);

            article.appendChild(message_header);
            article.appendChild(message_body);
            article.appendChild(buttons);
            this.appendChild(article);
        }

        public AppElement getInput()
        {
            return this.textarea;
        }
    }

    public void abortButton()
    {
        this.close();
    }

    public void mouseover()
    {
        System.out.println("oui");
    }

    public void commitButton(String message)
    {
        try
        {
            System.out.println("  This would be the content of the message ============>" + message);
            GitCommitEntity commitEntity = new GitCommitEntity();
            commitEntity.execute(IDE.projectInit,message);
            this.close();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    static boolean answer;
    private PopUpElement popUpElement = null;

    public PopUpWindow()
    {
        super();
    }

    private void dispatch()
    {
        var doc = this.getBrowser().getEngine().getDocument();
        this.updateCSS(IDE.singleton.getTheme().toString());

        Element app = doc.getElementById("app");
        this.popUpElement = new PopUpElement("div", this.getBrowser().getEngine());
        app.appendChild(this.popUpElement.getElement());

        var js = (JSObject) this.getBrowser().getEngine().executeScript("window");
        js.setMember("popup", this);
    }

    public void close()
    {
        this.getStage().close();
    }

    public void show()
    {
        Stage stage = new Stage();
        stage.setTitle("Commit");

        this.load(stage);

        stage.setHeight(180);
        stage.setWidth(720);
        stage.setMaxHeight(180);
        stage.setMaxWidth(720);

        this.getBrowser().getEngine().getLoadWorker().stateProperty().addListener((ov, oldState, newState) ->
        {
            if (newState == Worker.State.SUCCEEDED)
            {
                this.dispatch();
                System.out.println("READY");
            }
        });
    }
}
