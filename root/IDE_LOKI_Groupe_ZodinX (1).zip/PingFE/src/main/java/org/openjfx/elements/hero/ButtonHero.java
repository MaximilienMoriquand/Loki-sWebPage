package org.openjfx.elements.hero;

import javafx.stage.Stage;
import org.openjfx.App;
import org.openjfx.elements.explorer.Explorer;
import org.openjfx.elements.AppElement;

public class ButtonHero extends AppElement
{
    static Explorer explorer = null;

    public ButtonHero(String tagName, String type)
    {
        super("a", Hero.singleton.getEngine());
        this.addClass("navbar-item");
        String name = type.split("Onclick")[1];
        this.addEventListener(Event.CLICK,type);
        this.setTextContent(name);
    }

    public void OnclickNew()
    {
        Hero.singleton.openNewProjectExplorer();
    }

    public void OnclickOpen()
    {
        Hero.singleton.openProjectExplorer();
    }

    public void OnclickExit()
    {
        System.out.println("Exiting via exit button");
        System.exit(0);

    }

    public void OnclickHelp()
    {
        System.out.println("Help");
    }

    public void OnclickDocumentation()
    {
        Hero.singleton.OpenDoc();
    }

    public void OnclickGithub()
    {
        Hero.singleton.OpenBenoist();
    }

    public  void OnclickSite()
    {
        Hero.singleton.OpenSite();
    }
}
