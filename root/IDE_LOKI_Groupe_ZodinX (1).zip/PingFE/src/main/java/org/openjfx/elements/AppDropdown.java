package org.openjfx.elements;

import javafx.scene.web.WebEngine;

public class AppDropdown extends AppElement
{
    private final AppElement dropdown_trigger;
    private final AppElement dropdown_menu;
    private final AppElement dropdown_menu_content;

    public AppDropdown(WebEngine engine)
    {
        super("div", engine);
        this.addClass("dropdown");

        this.dropdown_menu = new AppElement("div", engine);
        this.dropdown_menu.addClass("dropdown-menu");
        this.dropdown_menu.setAttribute("role", "menu");

        this.dropdown_menu_content = new AppElement("div", engine);
        this.dropdown_menu_content.addClass("dropdown-content");
        this.dropdown_menu.appendChild(this.dropdown_menu_content);

        this.dropdown_trigger = new AppElement("div", engine);
        this.dropdown_trigger.addClass("dropdown-trigger");
        this.appendChild(this.dropdown_trigger);

        this.appendChild(this.dropdown_menu);
    }
}
