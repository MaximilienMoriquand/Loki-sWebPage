package org.openjfx.elements.hero;

import org.openjfx.elements.AppElement;

import java.util.ArrayList;

public class HNave extends AppElement
{
    private class NavBarrItem extends AppElement
    {
        public NavBarrItem(String tagName,String content)
        {
            super(tagName, Hero.singleton.getEngine());
            this.addClass("navbar-item");
            this.setTextContent(content);
        }
    }

    private class NavBarrEnd extends AppElement
    {
        public NavBarrEnd(String tagName,ArrayList<AppElement> content)
        {
            super(tagName, Hero.singleton.getEngine());
            this.addClass("navbar-end");
            content.forEach(a->
            {
                this.appendChild(a);
            });
        }
    }

    private class NavBarMenue extends AppElement
    {

        public NavBarMenue(String tagName,AppElement NavBarEnd)
        {
            super(tagName, Hero.singleton.getEngine());
            this.addClass("navbar-menu");
            this.appendChild(NavBarEnd);
        }
    }

    private ButtonHero New;

    private AppElement  container;
    private ArrayList<AppElement> ListMenue;
    private AppElement Open;
    private AppElement Help;
    private AppElement Exit;
    private AppElement Exit_Button;
    private NavBarrEnd navend;
    private AppElement navBarMenue;

    public HNave(String tagName)
    {
        super(tagName, Hero.singleton.getEngine());
        this.addClass("navbar");
         container = new AppElement("div", Hero.singleton.getEngine());
        container.addClass("container");
        // item of the menu
         ListMenue = new ArrayList<>();
        this.New = new ButtonHero("a","OnclickNew");
         Open= new ButtonHero("a","OnclickOpen");
         Help =new ButtonHero("a","OnclickHelp");
         Exit= new ButtonHero("a","OnclickExit");
        ListMenue.add(this.New);
        ListMenue.add(Open);
      //  ListMenue.add(Help);
        // Exit Button
         Exit_Button = new AppElement("span", Hero.singleton.getEngine());
        Exit_Button.addClass("navbar-item");

        Exit.addClass("button is-danger ");
        Exit.setTextContent("Exit");
        Exit_Button.appendChild(Exit);
        ListMenue.add(Exit_Button);
         navend = new NavBarrEnd("div",ListMenue);
         navBarMenue = new NavBarMenue("div",navend);
        container.appendChild(navBarMenue);
        this.appendChild(container);


    }
}
