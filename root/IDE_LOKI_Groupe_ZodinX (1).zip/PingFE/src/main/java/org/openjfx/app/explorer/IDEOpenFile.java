package org.openjfx.app.explorer;

import netscape.javascript.JSObject;
import org.openjfx.app.IDE;
import org.openjfx.elements.explorer.Explorer;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;

public class IDEOpenFile extends Explorer
{
    public IDEOpenFile()
    {
        super(true);
        this.setPath(IDE.singleton.project_path());
        this.show();
    }

    @Override
    public void open(Path path)
    {
        System.out.println(path.toString());
        if (path.toFile().isDirectory()){
            return;
        }

        File file = path.toFile();

        String file_text = "Possible error while reading file";
        try {
            file_text = Files.readString(Path.of(file.getAbsolutePath()));
        }
        catch (Exception e)
        {
            return;
        }

        file_text = file_text.replace("\r", "");
        file_text = file_text.replace("\n", "\\n");
        System.out.println(file_text);
        String filePath = Path.of(file.getAbsolutePath()).toString();
        filePath = filePath.replace("\\", "\\\\");

        String chose = "var content = '" + file_text + "';var susposter= document.querySelector('.textarea');susposter.value=content;var impostor= document.querySelector('#pathcontainer');impostor.value='" + filePath + "';console.log('IMPOSTOR PATH CONTAINER = ' + impostor.value);pathsaver();";
        IDE.singleton.app.getBrowser().getEngine().executeScript(chose);
        IDE.singleton.current_file_path = filePath;
        IDE.singleton.textarea_content = file_text;
        hide();
    }

    @Override
    public void hide()
    {
        IDE.singleton.clearExplorer(this);
    }
}
