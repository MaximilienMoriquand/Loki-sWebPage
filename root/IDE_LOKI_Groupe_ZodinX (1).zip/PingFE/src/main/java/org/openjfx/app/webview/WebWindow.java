package org.openjfx.app.webview;

import javafx.scene.Scene;
import javafx.scene.layout.VBox;
import javafx.scene.web.WebView;
import javafx.stage.Stage;
import org.openjfx.App;
import org.openjfx.elements.nav.AppNavBar;

public   class WebWindow {


    private App window;
    private String url;

    public   static void  show( String url)
    {
        Stage stage = new Stage();
        WebView webView = new WebView();
        webView.getEngine().load(url);
        VBox vBox = new VBox(webView);
        Scene scene = new Scene(vBox, 960, 600);
        stage.setScene(scene);
        stage.show();
    }
}


