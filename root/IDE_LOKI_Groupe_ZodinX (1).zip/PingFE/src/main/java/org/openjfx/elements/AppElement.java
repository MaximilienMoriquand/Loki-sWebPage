package org.openjfx.elements;

import javafx.scene.web.WebEngine;
import netscape.javascript.JSObject;
import org.openjfx.App;
import org.w3c.dom.Element;

import java.util.function.Function;

public class AppElement
{
    public enum Event
    {
        ABORT("onabort"),
        AFTER_PRINT("onafterprint"),
        BEFORE_PRINT("onbeforeprint"),
        BEFORE_UNLOAD("onbeforeunload"),
        BLUR("onblur"),
        CAN_PLAY("oncanplay"),
        CAN_PLAY_THROUGH("oncanplaythrough"),
        CHANGE("onchange"),
        CLICK("onclick"),
        CONTEXT_MENU("oncontextmenu"),
        COPY("oncopy"),
        CUT("oncut"),
        DOUBLE_CLICK("ondblclick"),
        DRAG("ondrag"),
        DRAG_END("ondragend"),
        DRAG_ENTER("ondragenter"),
        DRAG_LEAVE("ondragleave"),
        DRAG_OVER("ondragover"),
        DRAG_START("ondragstart"),
        DROP("ondrop"),
        DURATION_CHANGED("ondurationchange"),
        ENDED("onended"),
        ERROR("onerror"),
        FOCUS("onfocus"),
        FOCUS_IN("onfocusin"),
        FOCUS_OUT("onfocusout"),
        FULLSCREEN_CHANGE("onfullscreenchange"),
        FULLSCREEN_ERROR("onfullscreenerror"),
        HASH_CHANGE("onhashchange"),
        INPUT("oninput"),
        INVALID("oninvalid"),
        KEY_DOWN("onkeydown"),
        KEY_PRESS("onkeypress"),
        KEY_UP("onkeyup"),
        LOAD("onload"),
        LOADED_DATA("onloadeddata"),
        LOADED_METADATA("onloadedmetadata"),
        LOAD_START("onloadstart"),
        MESSAGE("onmessage"),
        MOUSE_DOWN("onmousedown"),
        MOUSE_ENTER("onmouseenter"),
        MOUSE_LEAVE("onmouseleave"),
        MOUSE_MOVE("onmousemove"),
        MOUSE_OVER("onmouseover"),
        MOUSE_OUT("onmouseout"),
        MOUSE_UP("onmouseup"),
        OFFLINE("onoffline"),
        ONLINE("ononline"),
        OPEN("onopen"),
        PAGE_HIDE("onpagehide"),
        PAGE_SHOW("onpageshow"),
        PASTE("onpaste"),
        PAUSE("onpause"),
        PLAY("onplay"),
        PLAYING("onplaying"),
        PROGRESS("onprogress"),
        RATE_CHANGED("onratechange"),
        RESIZE("onresize"),
        RESET("onreset"),
        SCROLL("onscroll"),
        SEARCH("onsearch"),
        SEEKED("onseeked"),
        SEEKING("onseeking"),
        SELECT("onselect"),
        SHOW("onshow"),
        STALLED("onstalled"),
        SUBMIT("onsubmit"),
        SUSPEND("onsuspend"),
        TIME_UPDATE("ontimeupdate"),
        TOGGLE("ontoggle"),
        TOUCH_CANCEL("ontouchcancel"),
        TOUCH_END("ontouchend"),
        TOUCH_MOVE("ontouchmove"),
        TOUCH_START("ontouchstart"),
        UNLOAD("onunload"),
        VOLUME_CHANGED("onvolumechange"),
        WAITING("onwaiting"),
        WHEEL("onwheel");
        private final String name;

        Event(final String name)
        {
            this.name = name;
        }

        @Override
        public String toString()
        {
            return this.name;
        }
    }

    private final Element element;
    private final String jsName;

    private static int element_id = 0;

    private int getNewId()
    {
        return element_id++;
    }

    public AppElement(final String tagName, final WebEngine engine)
    {
        var doc = engine.getDocument();

        this.element = doc.createElement(tagName);
        this.jsName = "java_app_" + this.getNewId();

        JSObject window = (JSObject)engine.executeScript("window");
        window.setMember(this.getJSVar(), this);

        this.element.setAttribute("id", this.getJSVar());
    }

    public void addEventListener(Event event, final String func)
    {
        this.element.setAttribute(event.toString(), this.getJSVar() + "." + func + "()");
        System.out.println("addEventListener: Event(\"" + event.toString() + "\") func: " + this.getJSVar() + "." + func);
    }

    public void addEventListener(Event event, AppElement element, final String func)
    {
        this.element.setAttribute(event.toString(), element.getJSVar() + "." + func + "()");
        System.out.println("addEventListener: Event(\"" + event.toString() + "\") func: " + element.getJSVar() + "." + func);
    }

    public String getJSVar()
    {
        return this.jsName;
    }

    public Element getElement()
    {
        return this.element;
    }
    
    public void addClass(final String className)
    {
        var val = this.element.getAttribute("class");
        if (val != null)
        {
            String[] classes = val.split(" ");
            for (String c : classes)
            {
                if (c.equals(className))
                {
                    return;
                }
            }
            val = val + " ";
        }
        else
        {
            val = "";
        }
        this.element.setAttribute("class", val + className);
    }

    public void removeClass(final String className)
    {
        var classes = this.element.getAttribute("class");
        String[] elClass = classes.split(" ");
        StringBuilder val = new StringBuilder();
        for (String c: elClass)
        {
            if (!c.equals(className))
            {
                val.append(c).append(" ");
            }
        }
        this.element.setAttribute("class", val.toString());
    }

    public void setTextContent(final String text)
    {
        this.element.setTextContent(text);
    }

    public final String getTextContent()
    {
        return this.element.getTextContent();
    }

    public void setAttribute(final String name, final String value)
    {
        this.element.setAttribute(name, value);
    }

    public final String getAttribute(final String name)
    {
        return this.element.getAttribute(name);
    }

    public final void removeAttribute(final String name)
    {
        this.element.removeAttribute(name);
    }

    public final void addAttribute(final String name)
    {
        this.element.setAttribute(name, "");
    }

    public final boolean hasAttribute(final String name)
    {
        return this.element.hasAttribute(name);
    }

    public void appendChild(AppElement element)
    {
        this.element.appendChild(element.getElement());
    }

    public void removeChild(AppElement element)
    {
        this.element.removeChild(element.getElement());
    }
}