package org.openjfx.app;

import javafx.scene.web.WebEngine;
import netscape.javascript.JSObject;
import org.openjfx.App;
import org.openjfx.app.hierarchy.Hierarchy;
import org.openjfx.elements.AppElement;

import java.io.File;

public class Body {
    public AppElement content;
    public AppElement columnh;
    public AppElement columtxt;
    public Hierarchy hierarchy;
    public CodeArea codeArea;
    private File root;

    public App window;
    public WebEngine engine;

    public Body(App window, File root) throws Exception {
        this.window = window;
        this.root = root;
        this.engine = window.getBrowser().getEngine();
        content = new AppElement("div", engine);
        content.addClass("columns");
        this.columtxt = new AppElement("div", engine);
        this.columnh = new AppElement("div", engine);
        this.hierarchy = new Hierarchy(root, window);
        // TODO rewritre the class codeArea
        this.codeArea = new CodeArea(engine);
        //this.codeArea.addEventListener(AppElement.Event.CHANGE, "SaveFollowup()");
        this.codeArea.setAttribute("id", "code");
        columnh.addClass("column is-2");
        columnh.appendChild(hierarchy.content);
        columtxt.addClass("column");
        columtxt.appendChild(codeArea);
        content.appendChild(columnh);
        content.appendChild(columtxt);


        this.window = window;
        this.engine = window.getBrowser().getEngine();
    }

    public void reloadHierarchy() {
        this.hierarchy = new Hierarchy(root, window);
    }

    void onclikmaventest()
    {
        System.out.println("hello");
        System.out.println("sortie");
    }

    public void load(File root) throws Exception {

        var Body = new Body(window, root);
        this.window.updateCSS();
        // Set the title
        var span = new AppElement("span", engine);
        span.setTextContent("IDE Explorer");
        var doc = engine.getDocument();
        var app = doc.getElementById("app");
        JSObject window = (JSObject) engine.executeScript("window");
        window.setMember("explorer", this);
        app.appendChild(this.content.getElement());
    }

}

