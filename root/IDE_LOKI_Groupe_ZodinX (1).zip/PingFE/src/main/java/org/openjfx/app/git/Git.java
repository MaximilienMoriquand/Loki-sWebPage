package org.openjfx.app.git;

import fr.epita.assistants.myide.domain.entity.*;
import javafx.scene.web.WebEngine;
import javafx.stage.Stage;
import org.openjfx.app.IDE;
import org.openjfx.app.maven.Maven;

import java.io.IOException;

public class Git
{
    public Project current_project;
    public static Git singleton;
    public  String commit_message;
    public String pwd;
    public String auth;
    private PopUpWindow popUpWindow;
    private PushPopUp pushPopUp;
    private  PullPopUp pullPopUp;
    public Git() throws Exception
    {
        if (singleton != null)
        {
            throw new Exception("git object already created");
        }
        IDE.git=this;
        this.current_project = IDE.projectInit;
    }
    public void pull(Object... args)
    {
        pullPopUp = new PullPopUp();
        pullPopUp.show();
    }
    public void commit(Object... args)
    {
        popUpWindow = new PopUpWindow();
        popUpWindow.show();
    }
    public void push(Object... args)
    {
        pushPopUp = new PushPopUp();
        pushPopUp.show();
    }
    public void add(WebEngine engine, String root_path, Object... args)
    {
        var path = engine.getDocument().getElementById("pathcontainer").getTextContent();
        System.out.println("PATH BEFORE : " + path);
        path = path.replace(root_path + "\\", "");
        System.out.println("PATH FOR ADD IS : " + path);
        System.out.println("Adding");
        GitAddEntity gitAddEntity = new GitAddEntity();
        var a=gitAddEntity.execute(this.current_project, path);
        System.out.println("add==>"+a.isSuccess());
    }

}
