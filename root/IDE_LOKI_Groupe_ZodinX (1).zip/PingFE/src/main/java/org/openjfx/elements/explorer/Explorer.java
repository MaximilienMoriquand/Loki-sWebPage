package org.openjfx.elements.explorer;

import fr.epita.assistants.myide.domain.entity.Node;
import fr.epita.assistants.myide.domain.entity.NodeEntity;
import javafx.concurrent.Worker;
import javafx.scene.web.WebEngine;
import javafx.stage.Stage;
import netscape.javascript.JSObject;
import org.openjfx.App;
import org.openjfx.app.IDE;
import org.openjfx.elements.AppElement;
import org.openjfx.elements.icon.Icon;
import org.openjfx.elements.nav.AppNavBar;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class Explorer
{
    public class ExplorerSaveFile extends AppElement
    {
        final private Node.Types type;
        final private AppElement input;
        final private AppElement button;

        public ExplorerSaveFile(Node.Types type, WebEngine engine)
        {
            super("field", engine);

            this.type = type;

            var p = new AppElement("p", engine);
            p.addClass("control has-icons-left has-icons-right");

            this.input = new AppElement("input", engine);
            this.input.addClass("input");
            this.input.setAttribute("type", "text");
            this.input.setAttribute("placeholder", "Name");

            p.appendChild(this.input);
            var icon = new Icon((type == Node.Types.FILE) ? "far fa-file-alt" : "fas fa-folder", engine);
            icon.addClass("is-small is-left");
            p.appendChild(icon);

            this.button = new AppElement("button", engine);
            this.button.addClass("button");
            this.button.setTextContent("Save");
            this.button.setAttribute(Event.CLICK.toString(), "explorer.onSave(document.getElementById('" + this.input.getJSVar() + "').value);");

            p.appendChild(this.button);

            this.appendChild(p);
        }
    }

    public class ExplorerCreateDir extends AppElement
    {
        private AppElement a;
        private AppElement input;

        public ExplorerCreateDir(WebEngine engine)
        {
            super("li", engine);

            this.a = new AppElement("a", engine);
            this.a.appendChild(new Icon("fas fa-folder", engine));
            this.appendChild(this.a);

            var span = new AppElement("span", engine);
            this.input = new AppElement("input", engine);
            this.addClass("input");
            this.setAttribute("type", "text");
            span.appendChild(input);
            this.a.appendChild(span);
        }

        public void hide()
        {
            this.addAttribute("hidden");
        }

        public void show()
        {
            this.removeAttribute("hidden");
        }
    }

    public class ExplorerItem extends AppElement
    {
        private AppElement a;

        public ExplorerItem(WebEngine engine, Node node)
        {
            super("li", engine);
            this.a = new AppElement("a", engine);
            if (node.isFolder())
            {
                this.a.appendChild(new Icon("fas fa-folder", engine));
            }
            else
            {
                this.a.appendChild(new Icon("far fa-file-alt", engine));
            }

            this.appendChild(this.a);
            var span = new AppElement("span", engine);
            span.setTextContent(node.getPath().getFileName().toString());
            this.a.appendChild(span);
        }

        public void setActive()
        {
            this.a.addClass("is-active");
        }

        public void removeActive()
        {
            this.a.removeClass("is-active");
        }
    }

    public class ExplorerElement extends AppElement
    {
        private final AppElement label;
        private final AppElement menu;
        private final ExplorerCreateDir dirElement;
        private final List<AppElement> children;
        private final WebEngine engine;

        public ExplorerElement(WebEngine engine)
        {
            super("aside", engine);
            this.addClass("menu");

            this.label = new AppElement("p", engine);
            this.label.addClass("menu-label");
            this.appendChild(this.label);

            this.menu = new AppElement("ul", engine);
            this.menu.addClass("menu-list");
            this.appendChild(this.menu);

            this.dirElement = new ExplorerCreateDir(engine);
            //this.menu.appendChild(this.dirElement);

            this.engine = engine;
            this.children = new ArrayList<>();
        }

        public void setLabel(String name)
        {
            this.label.setTextContent(name);
        }

        public void clear()
        {
            for (AppElement c : this.children)
            {
                this.menu.removeChild(c);
            }
            this.children.clear();
        }

        public AppElement addItem(Node node)
        {
            var li = new ExplorerItem(this.engine, node);

            this.menu.appendChild(li);
            this.children.add(li);

            return li;
        }
    }

    private final App window;
    private final boolean openFile;
    private boolean saveFile;
    private Node.Types saveFileType;
    private List<NodeEntity> prevNodes;
    private NodeEntity currentNode;
    private ExplorerElement element;

    private NodeEntity selectedNode;
    private ExplorerItem selectedElement;
    private ExplorerSaveFile saveFileElement;
    private AppElement undoButton;
    private AppElement openButton;
    private AppElement closeButton;
    private AppElement createDirButton;

    private AppNavBar navbar;

    private boolean reloading;

    public Explorer(boolean openFile)
    {
        this.window = new App();
        this.reloading = false;
        this.selectedElement = null;
        this.openFile = openFile;
        this.saveFile = false;
        this.saveFileType = Node.Types.FOLDER;
        this.prevNodes = new ArrayList<>();
    }

    public void createFile(Node.Types type)
    {
        this.saveFileType = type;
        this.saveFile = true;
    }

    public void setPath(final Path path)
    {
        Path searchPath = path;
        while (searchPath != null)
        {
            try
            {
                File f = Paths.get(searchPath + "/..").toFile().getCanonicalFile();
                Path newPath = Paths.get(f.getPath());
                if (newPath.equals(searchPath))
                {
                    break;
                }
                searchPath = newPath;
                this.prevNodes.add(0, new NodeEntity(newPath, Node.Types.FOLDER, 1));
            }
            catch (Exception ignored)
            {
                break;
            }
        }
        this.currentNode = new NodeEntity(path, Node.Types.FOLDER, 1);
        this.reloading = false;
    }

    public void setProject(final Node projectNode)
    {
        Paths.get(projectNode.getPath().toString() + "/..");
        this.currentNode = new NodeEntity(projectNode.getPath(), Node.Types.FOLDER, 1);
    }

    public void show()
    {
        Stage stage = new Stage();
        stage.setTitle("IDE Explorer");
        this.window.load(stage);

        this.window.getBrowser().getEngine().getLoadWorker().stateProperty().addListener((ov, oldState, newState) ->
        {
            if (newState == Worker.State.SUCCEEDED)
            {
                this.load();
                System.out.println("READY");
            }
        });
    }

    public void close()
    {
        this.window.getStage().close();
    }

    public void load()
    {
        WebEngine engine = this.window.getBrowser().getEngine();
        this.element = new ExplorerElement(engine);
        this.window.updateCSS(IDE.singleton.getTheme().toString());

        /* **************** */
        /* Setup the navbar */
        /* **************** */
        this.navbar = new AppNavBar(engine);
        // Set the title
        // var span = new AppElement("span", engine);
        // span.setTextContent("IDE Explorer");
        // this.navbar.getNavBrand().appendChild(span);
        // Setup the buttons
        // Undo button
        this.undoButton = AppNavBar.createItem(engine);
        this.undoButton.appendChild(new Icon("fas fa-undo", engine));
        this.undoButton.setAttribute(AppElement.Event.CLICK.toString(), "explorer.undo();");
        this.navbar.getNavMenu().getNavBarStart().appendChild(this.undoButton);
        // Open icon
        this.openButton = AppNavBar.createItem(engine);
        this.openButton.appendChild(new Icon("far fa-folder-open", engine));
        this.openButton.setAttribute(AppElement.Event.CLICK.toString(), "explorer.select();");
        if (!this.saveFile)
        {
            this.navbar.getNavMenu().getNavBarStart().appendChild(this.openButton);
        }
        // Create dir icon
        this.createDirButton = AppNavBar.createItem(engine);
        this.createDirButton.appendChild(new Icon("fas fa-folder-plus", engine));
        this.createDirButton.setAttribute(AppElement.Event.CLICK.toString(), "explorer.createDir();");
        //this.navbar.getNavMenu().getNavBarStart().appendChild(this.createDirButton);

        this.closeButton = AppNavBar.createItem(engine);
        // Close icon
        this.closeButton.appendChild(new Icon("fas fa-times", engine));
        this.closeButton.setAttribute(AppElement.Event.CLICK.toString(), "explorer.hide();");
        this.navbar.getNavMenu().getNavBarEnd().appendChild(this.closeButton);

        var doc = engine.getDocument();
        var app = doc.getElementById("app");

        JSObject window = (JSObject) engine.executeScript("window");
        window.setMember("explorer", this);

        app.appendChild(this.navbar.getElement());

        var section = new AppElement("section", engine);
        section.addClass("section");
        section.appendChild(this.element);
        if (this.saveFile)
        {
            this.saveFileElement = new ExplorerSaveFile(this.saveFileType, engine);
            section.appendChild(this.saveFileElement);
        }
        app.appendChild(section.getElement());

        this.reload(this.currentNode);
    }

    protected void draw()
    {
        this.selectedElement = null;
        this.element.clear();
        this.element.setLabel(this.currentNode.getPath().toString());
        this.currentNode.updateChildren(1);

        WebEngine engine = this.window.getBrowser().getEngine();
        JSObject window = (JSObject) engine.executeScript("window");

        var nodes = this.currentNode.getChildren();
        for (var i = 0;
             i < nodes.size();
             i++)
        {
            var n = nodes.get(i);
            AppElement button = null;
            if (n.isFolder())
            {
                button = this.element.addItem(n);
            }
            else if (this.openFile)
            {
                button = this.element.addItem(n);
            }

            if (button != null)
            {
                button.setAttribute(AppElement.Event.CLICK.toString(), "explorer.exploreNode(" + button.getJSVar() + "," + i + ");");
                button.setAttribute(AppElement.Event.DOUBLE_CLICK.toString(), "explorer.openNode(" + button.getJSVar() + "," + i + ");");
            }
        }
    }

    public void reload(NodeEntity newNode)
    {
        if (this.currentNode != newNode)
        {
            this.prevNodes.add(this.currentNode);
        }

        this.currentNode = newNode;
        this.draw();
        this.reloading = false;
    }

    public void exploreNode(ExplorerItem element, int i)
    {
        if (this.selectedElement != null)
        {
            this.selectedElement.removeActive();
        }
        element.setActive();
        this.selectedElement = element;
        this.selectedNode = (NodeEntity) this.currentNode.getChildren().get(i);
    }

    public void openNode(ExplorerItem element, int i)
    {
        NodeEntity n = (NodeEntity) this.currentNode.getChildren().get(i);
        if (n.isFolder())
        {
            this.reload(n);
        }
        else if (this.openFile && !this.saveFile)
        {
            this.open(n.getPath());
        }
    }

    public void select()
    {
        if (this.saveFile || this.selectedNode == null || (openFile && this.selectedNode.isFolder()))
        {
            return;
        }

        this.open(this.selectedNode.getPath());
    }

    public void undo()
    {
        if (this.reloading)
        {
            return;
        }

        var s = this.prevNodes.size();
        if (s <= 0)
        {
            return;
        }

        this.reloading = true;
        var node = this.prevNodes.get(s - 1);
        this.prevNodes.remove(s - 1);
        this.currentNode = node;
        this.reload(node);
    }

    public void onSave(final String name)
    {
        this.save(this.currentNode.getPath(), name);
    }

    public void open(Path path)
    {
        System.out.println("Explorer got: " + path.toString());
        System.err.println("But you didn't override the function!");
    }

    public void save(final Path path, final String name)
    {
        System.out.println("Explorer wants to save a file: " + name + "\nAt: " + path.toString());
        System.err.println("But you didn't override the function!");
    }

    public void hide()
    {
        System.out.println("Explorer got closed!");
        System.err.println("But you didn't override the function!");
    }
}
