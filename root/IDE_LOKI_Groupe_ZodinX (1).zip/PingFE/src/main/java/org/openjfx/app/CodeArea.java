package org.openjfx.app;

import javafx.scene.web.WebEngine;
import org.openjfx.App;
import org.openjfx.elements.AppElement;

public class CodeArea extends AppElement
{
    public CodeArea(WebEngine engine)
    {
        super("textarea",engine );
        this.addClass("textarea");
        this.setAttribute("rows", "30");
    }

    public void fill(String content)
    {
        System.out.println("eee");
        this.setTextContent(content);
    }

    public void openFile()
    {
        /*
        try
        {
            App.getBrowser().getEngine().executeScript("var input = document.createElement('input');input.type = 'file';input.onchange = e => {var file = e.target.files[0];var reader = new FileReader();reader.readAsText(file,'UTF-8');reader.onload = readerEvent => {var content = readerEvent.target.result;" + this.getJSVar() + ".fill(content);};};input.click();");
        }
        catch (Exception ignored)
        {
            System.out.println(ignored.getMessage());
        }
        */
        System.out.println("eeeee");
    }
}
