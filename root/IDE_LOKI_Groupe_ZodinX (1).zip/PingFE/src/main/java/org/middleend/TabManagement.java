package org.middleend;

import java.util.ArrayList;

public class TabManagement {
    ArrayList<Tab> _openTabs;
    Tab _currentTab;

    public TabManagement() {
        _openTabs = new ArrayList<>();
        _currentTab = null;
    }
/*
    public void AddTab(Tab tabToAdd)
    {
        if (_currentTab != null)
        {
            _currentTab.Save();
        }
        if (!_openTabs.contains(tabToAdd))
        {
            _openTabs.add(tabToAdd);
            _currentTab = tabToAdd;
        }
        else
        {
            _currentTab = _openTabs.stream().filter(tab -> tab.equals(tabToAdd)).findFirst().get();
        }
    }

    public void DeleteTab(Tab tab)
    {
        if (_openTabs.contains(tab))
        {
            tab.DeleteTemp();
            _openTabs.remove(tab);
        }
    }

    public void ChangeTab(Tab goalTab)
    {
        if (_openTabs.size() != 0)
        {
            _currentTab.Save();
            _currentTab = goalTab;
        }
    }*/
}
