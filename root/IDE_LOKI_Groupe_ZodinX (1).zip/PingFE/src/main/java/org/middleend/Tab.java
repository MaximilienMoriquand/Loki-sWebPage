package org.middleend;

import fr.epita.assistants.myide.domain.entity.Node;
import org.w3c.dom.Document;

import java.io.*;
import java.nio.Buffer;
import java.nio.file.Paths;

public class Tab {
    private final Node _node;
    private File _tempFile;
    private Document document;

    public Tab(Node node) {
        _node = node;
        if (node.getType() == Node.Types.FILE)
        {
            try {
                _tempFile = new File(node.getPath() + ".tmp");
                if (_tempFile.createNewFile())
                {
                    System.out.println(1);
                }
                else
                {
                    System.out.println(0);
                }
            }
            catch (IOException e)
            {
                // Do nothing
            }
        }
    }

    public void UpdateTemp(String text)
    {
        try {
            /*var textArea = document.getElementById("textarea");
            String textToUpdate = textArea.getTextContent();*/
            PrintWriter printWriter = new PrintWriter(_tempFile);
            printWriter.print(text);
            printWriter.close();
        }
        catch (IOException e)
        {
            // Do nothing
        }
    }

    public void DeleteTemp()
    {
        if (_tempFile.delete())
        {
            System.out.println("deleted");
        }
        else
        {
            System.out.println("No such file or directory");
        }
    }

    public void Save(String text)
    {
        try {
            UpdateTemp(text);
            BufferedReader reader = new BufferedReader(new FileReader(_tempFile));
            String textToSave = "";
            String line = reader.readLine();
            while (line != null)
            {
                textToSave = textToSave + line + System.lineSeparator();
                line = reader.readLine();
            }
            File fileToChange = _node.getPath().toFile();
            PrintWriter writer = new PrintWriter(fileToChange);
            writer.print(textToSave);
            writer.close();
        }
        catch (IOException e)
        {
            // Do nothing
        }
    }

    public void SaveAs(String path)
    {
        try {
            BufferedReader reader = new BufferedReader(new FileReader(_tempFile));
            StringBuilder textToSave = new StringBuilder();
            String line = reader.readLine();
            while (line != null)
            {
                textToSave.append(line).append(System.lineSeparator());
                line = reader.readLine();
            }
            File fileToChange = Paths.get(path).toFile();
            PrintWriter writer = new PrintWriter(fileToChange);
            writer.print(textToSave);
            writer.close();
        }
        catch (IOException e)
        {
            // Do nothing
        }
    }
}
