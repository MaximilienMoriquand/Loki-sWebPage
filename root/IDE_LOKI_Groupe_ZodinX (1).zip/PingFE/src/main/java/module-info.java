module org.openjfx {
    requires javafx.controls;
    requires javafx.web;
    requires jdk.jsobject;
    requires ping.ref;
    requires java.desktop;
    requires org.eclipse.jgit;
    exports org.openjfx;
    exports org.openjfx.app;
    exports org.openjfx.elements.hero;
    exports org.openjfx.elements.explorer;
    exports org.openjfx.app.explorer;
    exports org.openjfx.app.git;
}